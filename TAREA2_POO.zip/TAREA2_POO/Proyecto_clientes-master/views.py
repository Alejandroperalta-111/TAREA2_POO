from models import Cliente, Estudiante
from shared.json_manager import GestorJSON


class ClienteController:
    """CONTROLADOR: las operaciones CRUD. No imprime ni pide datos."""

    MODELO = Cliente
    ARCHIVO = "data/clientes.json"

    CAMPOS_BUSCABLES = (
        "id", "nombre", "apellido", "email", "telefono", "ciudad"
    )

    _gestor = GestorJSON(ARCHIVO)

    @classmethod
    def _registros(cls):
        return cls._gestor.leer()

    @classmethod
    def emails_registrados(cls, excepto_id=None):
        return {
            registro["email"].lower()
            for registro in cls._registros()
            if registro["id"] != excepto_id
        }

    @classmethod
    def siguiente_id(cls):
        ids = [registro["id"] for registro in cls._registros()]
        return max(ids) + 1 if ids else 1

    @staticmethod
    def _coincide(registro, termino, campos):
        for campo in campos:
            valor = str(registro.get(campo, "")).lower()
            if termino in valor:
                return True
        return False

    @classmethod
    def crear(cls, datos):
        try:
            faltantes = [
                campo for campo in cls.MODELO.OBLIGATORIOS
                if not str(datos.get(campo, "")).strip()
            ]
            if faltantes:
                return False, "Faltan campos obligatorios: " + ", ".join(faltantes)

            email = str(datos.get("email", "")).strip().lower()
            if email in cls.emails_registrados():
                return False, "Ese email ya está registrado"

            valores = {
                campo: datos.get(campo, "")
                for campo in cls.MODELO.CAMPOS
            }

            objeto = cls.MODELO(cls.siguiente_id(), **valores)
            registros = cls._registros()
            registros.append(objeto.a_diccionario())

            if not cls._gestor.guardar(registros):
                return False, "No se pudo escribir el archivo"

            return True, f"{objeto.nombre_completo} creado con id {objeto.id}"

        except ValueError as error:
            return False, str(error)

    @classmethod
    def listar(cls):
        return [
            cls.MODELO.desde_diccionario(registro)
            for registro in cls._registros()
        ]

    @classmethod
    def obtener(cls, id_registro):
        for objeto in cls.listar():
            if objeto.id == id_registro:
                return objeto
        return None

    @classmethod
    def buscar(cls, termino):
        termino = str(termino).strip().lower()
        if not termino:
            return []

        return [
            cls.MODELO.desde_diccionario(registro)
            for registro in cls._registros()
            if cls._coincide(registro, termino, cls.CAMPOS_BUSCABLES)
        ]

    @classmethod
    def actualizar(cls, id_registro, cambios):
        try:
            desconocidos = set(cambios) - set(cls.MODELO.CAMPOS)
            if desconocidos:
                return False, "Campos no válidos: " + ", ".join(sorted(desconocidos))

            if not cambios:
                return False, "No se indicó ningún cambio"

            objeto = cls.obtener(id_registro)
            if objeto is None:
                return False, f"No existe un registro con id {id_registro}"

            if "email" in cambios:
                nuevo = str(cambios["email"]).strip().lower()
                if nuevo in cls.emails_registrados(excepto_id=id_registro):
                    return False, "Ese email ya lo usa otro registro"

            for campo, valor in cambios.items():
                setattr(objeto, campo, valor)

            registros = cls._registros()
            for indice, registro in enumerate(registros):
                if registro["id"] == id_registro:
                    registros[indice] = objeto.a_diccionario()
                    break

            cls._gestor.guardar(registros)

            return True, (
                f"Registro {id_registro} actualizado "
                f"({len(cambios)} campo/s)"
            )

        except ValueError as error:
            return False, str(error)

    @classmethod
    def eliminar(cls, id_registro):
        registros = cls._registros()

        quedan = [
            registro for registro in registros
            if registro["id"] != id_registro
        ]

        if len(quedan) == len(registros):
            return False, f"No existe un registro con id {id_registro}"

        cls._gestor.guardar(quedan)
        return True, f"Registro {id_registro} eliminado"

    @classmethod
    def estadisticas(cls):
        registros = cls._registros()

        ciudades = {
            registro.get("ciudad", "")
            for registro in registros
            if registro.get("ciudad")
        }

        dominios = {
            registro["email"].split("@")[1]
            for registro in registros
            if "@" in registro["email"]
        }

        sin_telefono = [
            registro["nombre"]
            for registro in registros
            if not registro.get("telefono")
        ]

        return {
            "total": len(registros),
            "ciudades": sorted(ciudades),
            "dominios": sorted(dominios),
            "sin_telefono": sin_telefono,
        }


class EstudianteController(ClienteController):
    """Controlador de estudiantes."""

    MODELO = Estudiante
    ARCHIVO = "data/estudiantes.json"

    CAMPOS_BUSCABLES = (
        "id", "nombre", "apellido", "email", "carnet"
    )

    _gestor = GestorJSON(ARCHIVO)

    @classmethod
    def buscar(cls, termino):
        """Número = ID exacto; texto = nombre, apellido, email o carnet."""

        termino = str(termino).strip()

        if not termino:
            return []

        if termino.isdigit():
            id_buscado = int(termino)

            return [
                cls.MODELO.desde_diccionario(registro)
                for registro in cls._registros()
                if registro.get("id") == id_buscado
            ]

        termino = termino.lower()

        return [
            cls.MODELO.desde_diccionario(registro)
            for registro in cls._registros()
            if cls._coincide(
                registro,
                termino,
                ("nombre", "apellido", "email", "carnet")
            )
        ]

    @classmethod
    def carnets_registrados(cls, excepto_id=None):
        return {
            registro["carnet"].upper()
            for registro in cls._registros()
            if registro["id"] != excepto_id
        }

    @classmethod
    def crear(cls, datos):
        carnet = str(datos.get("carnet", "")).strip().upper()

        if carnet in cls.carnets_registrados():
            return False, "Ese carnet ya está registrado"

        return super().crear(datos)

    @classmethod
    def agregar_nota(cls, id_estudiante, materia, nota):
        estudiante = cls.obtener(id_estudiante)

        if estudiante is None:
            return False, f"No existe un estudiante con ID {id_estudiante}"

        try:
            estudiante.agregar_nota(materia, nota)

            registros = cls._registros()

            for indice, registro in enumerate(registros):
                if registro["id"] == id_estudiante:
                    registros[indice] = estudiante.a_diccionario()
                    break

            if not cls._gestor.guardar(registros):
                return False, "No se pudo guardar la nota"

            return True, f"Nota {nota} agregada a {materia}"

        except ValueError as error:
            return False, str(error)

    @classmethod
    def materias_ofertadas(cls):
        todas = set()

        for estudiante in cls.listar():
            todas.update(estudiante.materias)

        return todas

    @classmethod
    def materias_en_comun(cls, id_a, id_b):
        estudiante_a = cls.obtener(id_a)
        estudiante_b = cls.obtener(id_b)

        if not estudiante_a or not estudiante_b:
            return None, "Uno o ambos estudiantes no existen"

        comunes = estudiante_a.materias_en_comun(estudiante_b)

        return (
            comunes,
            f"Materias en común entre "
            f"{estudiante_a.nombre} y {estudiante_b.nombre}"
        )
